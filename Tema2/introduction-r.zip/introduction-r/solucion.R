# Exercise 1
years <- seq(2002, 2008, by=2)
years

# Excercise 2
lenght(years)

# Excercise 3
numbers <- c(1,2,3,4)
## Create a matrix, select from it
mat <- matrix(numbers, nrow=2, ncol=2)
row <- mat[1,]
col <- mat[,1]
item <- mat[1,1]

mat
row
col
## Create a list, select from it
### Lists are like python dictionaries
lt <- list(x=c(1,2,3), y=c('hello', 'there'))
lt

new_list_with_x <- lt['x']
old_list_y_selected <- lt$y

new_list_with_x
old_list_y_selected

## Create a dataframe, select from it
df <- data.frame(x=1:4, y=c('a', 'b','c','d')) # Just an excel table
View(df) ## Shows dataframe

col_1 <- df$x
col_2_element_2 <- df$y[2]

col_1
col_2_element_2

# Excercise 4
## Load data from CSV
fdata = read.csv("usedcars.csv",
                 header=TRUE,
                 sep=',')
# Exercises 5, 6
## Show data
View(fdata)
## Quick analysis
str(fdata)
summary(fdata)

# Exercise 7
fdata$color[5:20]

# Exercise 8
new_fdata <- fdata[-c(10,100),]
View(new_fdata)

# Exercise 9
new_fdata_2 <- fdata[,c(1,3,4)]
View(new_fdata_2)

# Exercise 10
sd(fdata$year)
mean(fdata$price)
sd(fdata$price)

# Exercise 11
## Calculate mean price by year and transmission
by(fdata$price,list(fdata$year, fdata$transmission), mean)

# Exercise 12
rows <- fdata[fdata$year %in% years,]
View(rows)

# Exercise 13
fdata$PM <- fdata$price * fdata$mileage 
View(fdata)

# Exercise 14
plot(fdata$price, type='l', main='Price')

# Exercise 15
plot(fdata$mileage, fdata$price)

# Exercise 16
boxplot(fdata$mileage, horizontal=TRUE)

# Exercise 17
hist(fdata$price)
